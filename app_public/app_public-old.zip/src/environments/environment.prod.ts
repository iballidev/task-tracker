export const environment = {
  production: true,
  baseUrl: 'https://production-api.com/api',
};
