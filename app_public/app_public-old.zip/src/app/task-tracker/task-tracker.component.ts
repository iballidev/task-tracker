
import { Component } from '@angular/core';

@Component({
  selector: 'app-task-tracker',
  standalone: false,
  templateUrl: './task-tracker.component.html',
  styleUrl: './task-tracker.component.scss',
})
export class TaskTrackerComponent {

}
