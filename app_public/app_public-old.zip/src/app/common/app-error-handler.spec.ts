import { AppErrorHandler } from './app-error-handler';

describe('AppErrorHandler', () => {
  it('should create an instance', () => {
    expect(new AppErrorHandler()).toBeTruthy();
  });
});
